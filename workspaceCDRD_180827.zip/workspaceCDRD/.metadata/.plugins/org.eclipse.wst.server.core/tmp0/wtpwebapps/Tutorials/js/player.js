/*
 * -------------------------------------------
 * Funções do perfil Jogador
 * -------------------------------------------
 */	

$(document).ready(function(){
	
	//Objeto que guardará o usuário logado assim que soubermos quem ele é
	var usuarioLogado;
	//Variável com base do caminho, ajudará na chamada das Servlets
	var PATH = "../../";
	
	//Função que chama a Servlet que trata da validação da sessão do usuário
	verificaUsuario = function(){
		$.ajax({
			type: "POST",
			url: PATH + "ValidaSessao",
			data: "p=1",
			success: function (usuario) {
				if (usuario.login!=null){
					usuarioLogado = new Object();
					usuarioLogado.login = usuario.login;
					usuarioLogado.email = usuario.email;
					usuarioLogado.nome = usuario.nome;
					usuarioLogado.nascimento = usuario.nascimento;
					carregaPagina();
				} else {
					sair();
				}	
			},
			error: function (info) {
				sair();
			}
		});
	}
	//Chama a função assim que a página for carregada
	verificaUsuario();
	
	
	//Função que faz o carregamento dos conteúdos das páginas dinamicamente
	carregaDados = function(pagename){
		switch(pagename){
			case "main":
				$("#username").html(usuarioLogado.login);
			break;
			case "myaccount":
				$("#nome").val(usuarioLogado.nome);
				$("#email").val(usuarioLogado.email);
				$("#nascimento").val(usuarioLogado.nascimento);
				$("#login").val(usuarioLogado.login);
				$("#senhaatual").val("");
				$("#novasenha").val("");
				$("#confsenha").val("");
			break;
		}
	}
	
	//Função que faz o carregamento das páginas dinamicamente
	carregaPagina = function(){
		var pagename = window.location.search.substring(1);
		if (pagename==""){
			pagename = "main";
		}
		$("#content").load(pagename+".html", function(response, status, info) {
			if (status == "error") {
				var msg = "Houve um erro ao encontrar a página: "+ info.status + " - " + info.statusText;
				$("#content").html(msg);
			} else {
				carregaDados(pagename);
			}
		});
	}

	//Função que chama a Servlet que trata da finalização da sessão do usuário
	sair = function(){
		$.ajax({
			type: "POST",
			url: PATH + "Logout",
			success: function (data) {
				window.location.href = (PATH+"index.html");	
			},
			error: function (info) {
				alert("Erro ao tentar encerrar sua sessão: "+ info.status + " - " + info.statusText);	
			}
		});
	}

	
	
/*
 * -------------------------------------------
 * Funções específicas do perfil Jogador
 * -------------------------------------------
 */	
	
	//Função que chama a Servlet que trata da alteração do cadastro do usuário logado
	alteraCadastro = function(){
		var nome = document.frmmyaccount.txtnome.value;
		var email = document.frmmyaccount.txtemail.value;
		var nascimento = document.frmmyaccount.txtnascimento.value;
		var login = document.frmmyaccount.txtlogin.value;
		var senhaatual = document.frmmyaccount.txtsenhaatual.value;
		var novasenha = document.frmmyaccount.txtnovasenha.value;
		var confsenha = document.frmmyaccount.txtconfsenha.value;
		if((senhaatual=="")||(novasenha=="")||(nome=="")||(email=="")||(nascimento=="")){
			alert("Não deixa nada vazio, meu!");
		} else if (novasenha!=confsenha){ 
			alert("Repete as duas senhas, né, meu!");
		} else {
			$.ajax({
				type: "POST",
				url: PATH + "EditaUsuario",
				data: $("#cadastroUsuario").serialize(),
				success: function (msg) {
					alert(msg.msg);
					if(!msg.erro)
						verificaUsuario();
				},
				error: function (info) {
					alert("Erro ao alterar seus dados: "+ info.status + " - " + info.statusText);		   
				}
			});
		}
	}
	
	//Função que chama a Servlet que trata da exclusão do cadastro do usuário logado
	excluiCadastro = function(){
		var confirma = confirm("Certeza? Fica mais um pouquinho...");
		if (confirma){
			$.ajax({
				type: "POST",
				url: PATH + "ExcluiUsuario",
				data: "login="+usuarioLogado.login,
				success: function (msg) {
					alert(msg.msg);
					sair();
				},
				error: function (info) {
					alert("Erro ao excluir seus dados: "+ info.status + " - " + info.statusText);		   
				}
			});
		}
	}
});
