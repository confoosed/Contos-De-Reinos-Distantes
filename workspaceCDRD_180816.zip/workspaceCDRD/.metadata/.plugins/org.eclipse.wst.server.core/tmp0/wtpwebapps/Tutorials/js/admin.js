/*
 * -------------------------------------------
 * Funções do perfil Administrador
 * -------------------------------------------
 */	

$(document).ready(function(){
	
	//Objeto que guardará o usuário logado assim que soubermos quem ele é
	var usuarioLogado;
	//Variável com base do caminho, ajudará na chamada das Servlets
	var PATH = "../../";
	
	//Função que chama a Servlet que trata da validação da sessão do usuário
	verificaUsuario = function(){
		$.ajax({
			type: "POST",
			url: PATH + "ValidaSessao",
			data: "p=0",
			success: function (usuario) {
				if (usuario.login!=null){
					usuarioLogado = new Object();
					usuarioLogado.login = usuario.login;
					usuarioLogado.email = usuario.email;
					usuarioLogado.nome = usuario.nome;
					usuarioLogado.nascimento = usuario.nascimento;
					carregaPagina();
				} else {
					sair();
				}	
			},
			error: function (info) {
				sair();
			}
		});
	}
	//Chama a função assim que a página for carregada
	verificaUsuario();
	
	
	//Função que faz o carregamento dos conteúdos das páginas dinamicamente
	carregaDados = function(pagename, data){
		switch(pagename){
			case "main":
				$("#username").html(usuarioLogado.login);
			break;
			case "admincrud":
				exibeAdministradores();
			break;
			case "adminedit":
				if (data==undefined){
					data = $("#login").val();
				}
				buscaAdministrador(data);
			break;
		}
	}
	
	//Função que faz o carregamento das páginas dinamicamente
	carregaPagina = function(){
		var pagename="";
		var data="";
		var url = window.location.search.substring(1);
		if (url==""){
			pagename = "main";
		} else {
			var splitted = url.split("=");
			pagename = splitted[0];
			if (splitted[1]){
				data = splitted[1];
			}
		}
		$("#content").load(pagename+".html", function(response, status, info) {
			if (status == "error") {
				var msg = "Houve um erro ao encontrar a página: "+ info.status + " - " + info.statusText;
				$("#content").html(msg);
			} else {
				carregaDados(pagename, data);
			}
		});
	}
	

	//Função que chama a Servlet que trata da finalização da sessão do usuário
	sair = function(){
		$.ajax({
			type: "POST",
			url: PATH + "Logout",
			success: function (data) {
				window.location.href = (PATH+"index.html");	
			},
			error: function (info) {
				alert("Erro ao tentar encerrar sua sessão: "+ info.status + " - " + info.statusText);	
			}
		});
	}

	
/*
 * -------------------------------------------
 * Funções específicas do perfil Administrador
 * -------------------------------------------
 */	

	//Função que chama a Servlet que trata do cadastro do usuário Administrador
	cadastraAdministrador = function(){
		var nome = document.frmregadmin.txtnome.value;
		var email = document.frmregadmin.txtemail.value;
		var nascimento = document.frmregadmin.txtnascimento.value;
		var login = document.frmregadmin.txtlogin.value;
		var senha = document.frmregadmin.txtsenha.value;
		var confsenha = document.frmregadmin.txtconfsenha.value;
		if((login=="")||(senha=="")||(nome=="")||(email=="")||(nascimento=="")){
			alert("Preencha tudo aí, meu!");
		} else if (senha!=confsenha){ 
			alert("Repete as duas senhas, né, meu!");
		} else {
			$.ajax({
				type: "POST",
				url: PATH + "InsereUsuario",
				data: $("#cadastroAdmin").serialize(),
				success: function (msg) {
					alert(msg.msg);
					carregaDados("admincrud");
				},
				error: function (info) {
					alert("Erro ao cadastrar um novo administrador: "+ info.status + " - " + info.statusText);		   
				}
			});
		}
	}
	
	//Função que chama a Servlet que trata da busca dos usuários registrados, conforme filtro
	exibeAdministradores = function(){
		var valorBusca = $("#busca").val();
		var html = "<table>" +
				"<tr>" +
				"<th>Nome</th>" +
				"<th>Login</th>" +
				"<th>E-mail</th>" +
				"<th>Nascimento</th>" +
				"<th>Ações</th>" +
				"</tr>";
		
		$.ajax({
			type: "POST",
			url: PATH + "ConsultaUsuarios",
			data: "permissao=0&valorBusca="+valorBusca,
			success: function(dados){
				html += geraTabelaAdministradores(dados);
				html += "</table>";
				$("#listaAdministradores").html(html);
			},
			error: function(info){
				alert("Erro ao consultar os contatos: "+ info.status + " - " + info.statusText);
			}
		});
		
	};

	//Função que gera o HTML interno da tabela de administradores registrados
	geraTabelaAdministradores = function(listaDeAdmins) {
		var dados = "";
		if (listaDeAdmins != undefined && listaDeAdmins.length > 0){
			for (var i=0; i<listaDeAdmins.length; i++){
				dados += "<tr>" +
						"<td>"+listaDeAdmins[i].nome+"</td>" +
						"<td>"+listaDeAdmins[i].login+"</td>" +
						"<td>"+listaDeAdmins[i].email+"</td>" +
						"<td>"+listaDeAdmins[i].nascimento+"</td>" +
						"<td>" +
							"<a href=\"?adminedit="+listaDeAdmins[i].login+"\">Editar</a> " +
							"<a onclick=\"deletaAdministrador('"+listaDeAdmins[i].login+"')\">Deletar</a>" +
						"</td>" +
						"</tr>"
			}
		} else if (listaDeAdmins == ""){
			dados += "<tr><td colspan='5'>Nenhum registro encontrado</td></tr>";
		}
		return dados;
	}
	
	//Função que chama a Servlet que trata da exclusão do cadastro do usuário Administrador selecionado
	deletaAdministrador = function(login){
		$.ajax({
			type:"POST",
			url: PATH + "ExcluiUsuario",
			data: "login="+login,
			success: function(msg){
				alert(msg.msg);
				carregaDados("admincrud");
			},
			error: function(info){
				alert("Erro ao deletar contato: "+ info.status + " - " + info.statusText);
			}
		});
	};
	
	//Função que chama a Servlet que trata da busca do cadastro do usuário Administrador selecionado
	buscaAdministrador = function(login){
		$.ajax({
			type: "POST",
			url: PATH + "ConsultaUsuarioPorLogin",
			data: "login="+login,
			success: function(contato){
				$("#nome").val(contato.nome);
				$("#email").val(contato.email);
				$("#nascimento").val(contato.nascimento);
				$("#login").val(contato.login);
				$("#senhaatual").val("");
				$("#novasenha").val("");
				$("#confsenha").val("");
			},
			error: function(rest){
				alert("Erro ao encontrar o usuário a ser alterado.");
			}
		});
		
	};
	
	//Função que chama a Servlet que trata da alteração do cadastro do usuário Administrador selecionado
	alteraUsuario = function(){
		var nome = document.frmadminedit.txtnome.value;
		var email = document.frmadminedit.txtemail.value;
		var nascimento = document.frmadminedit.txtnascimento.value;
		var login = document.frmadminedit.txtlogin.value;
		var senhaatual = document.frmadminedit.txtsenhaatual.value;
		var novasenha = document.frmadminedit.txtnovasenha.value;
		var confsenha = document.frmadminedit.txtconfsenha.value;
		if((senhaatual=="")||(novasenha=="")||(nome=="")||(email=="")||(nascimento=="")){
			alert("Não deixa nada vazio, meu!");
		} else if (novasenha!=confsenha){ 
			alert("Repete as duas senhas, né, meu!");
		} else {
			$.ajax({
				type: "POST",
				url: PATH + "EditaUsuario",
				data: $("#edicaoUsuario").serialize(),
				success: function (msg) {
					alert(msg.msg);
					if(!msg.erro)
						carregaPagina();
				},
				error: function (info) {
					alert("Erro ao alterar os dados: "+ info.status + " - " + info.statusText);		   
				}
			});
		}
	}


});
