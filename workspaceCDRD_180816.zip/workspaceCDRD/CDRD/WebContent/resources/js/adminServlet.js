$(document).ready(function(){
	var usuarioLogado;
	var PATH = "../../";
	
	verificaUsuario = function(){
		$.ajax({
			type: "POST",
			url: PATH + "ValidarSessao",
			data: "p=0",
			success: function (usuario) {
				if (usuario.login!=null){
					usuarioLogado = new Object();
					usuarioLogado.id= usuario.id;
					usuarioLogado.login = usuario.login;
					usuarioLogado.email = usuario.email;
					usuarioLogado.nome = usuario.nome;
					usuarioLogado.nascimento = usuario.nascimento;
					carregaPagina();
				} else {
					sair();
				}	
			},
			error: function (info) {
				sair();
			}
		});
	}
	
	verificaUsuario();
	
	insereNotificacao = function(){
		var notificacao = $("textarea[name=txacompnotificacao]").val();
		var usuarioId = usuarioLogado.id;
		$.ajax({
			type: "POST",
			url: PATH + "InserirNotificacao",
			data: $("form[name=frmcompornotificacoes]").serialize(),
			success: function (msg) {
				alert(msg.msg);
			},
			error: function (info) {
				alert("Erro ao cadastrar um novo administrador: "+ info.status + " - " + info.statusText);		   
			}
		});
	}
})

deletaNotificacao = function(login){
		$.ajax({
			type:"POST",
			url: PATH + "DeletarNotificacao",
			data: "login="+login,
			success: function(msg){
				alert(msg.msg);
				carregaDados("admincrud");
			},
			error: function(info){
				alert("Erro ao deletar contato: "+ info.status + " - " + info.statusText);
			}
		});
	};