/*
 * -------------------------------------------
 * Funções do perfil Visitante
 * -------------------------------------------
 */	

$(document).ready(function(){

	//Função que faz o carregamento das páginas dinamicamente
	carregaPagina = function(){
		var pagename = window.location.search.substring(1);
		if (pagename==""){
			pagename = "main";
		}
		$("#content").load("pages/visitor/"+pagename+".html", function(response, status, info) {
			if (status == "error") {
				var msg = "Houve um erro ao encontrar a página: "+ info.status + " - " + info.statusText;
				$("#content").html(msg);
			}
		});
	}
	//Chama o carregamento da página, fazendo com que a main se abra assim que o site for acessado 
	carregaPagina();

	//Função que chama a Servlet que trata do esquecimento da senha
	esqueciSenha = function(){
		var email = prompt("Digite seu e-mail para recuperar sua senha:");
		alert(email);
		$.ajax({
			type: "POST",
			url: "RecuperaSenha",
			success: function (msg) {
				alert(msg.msg);
			},
			error: function (info) {
				alert("Erro ao enviar e-mail: "+ info.status + " - " + info.statusText);		   
			}
		});
	}
	
	
	//Função que chama a Servlet que trata da autenticação no sistema
	login = function(){
		var login = document.frmlogin.txtlogin.value;
		var senha = document.frmlogin.txtsenha.value;
		if((login=="")||(senha=="")){
			alert("Preencha tudo aí, meu!");
		} else {
			$.ajax({
				type: "POST",
				url: "Login",
				data: "login="+login+"&senha="+senha,
				success: function (msg) {
					if (msg.msg!=null)
						alert(msg.msg);
					else
						window.location.href = msg.url;
				},
				error: function (info) {
					alert("Erro ao tentar login: "+ info.status + " - " + info.statusText);		   
				}
			});
		}
	}
	
	//Função que chama a Servlet que trata do cadastro de jogador
	cadastro = function(){
		var nome = document.frmsignup.txtnome.value;
		var email = document.frmsignup.txtemail.value;
		var nascimento = document.frmsignup.txtnascimento.value;
		var login = document.frmsignup.txtlogin.value;
		var senha = document.frmsignup.txtsenha.value;
		var confsenha = document.frmsignup.txtconfsenha.value;
		if((login=="")||(senha=="")||(nome=="")||(email=="")||(nascimento=="")){
			alert("Preencha tudo aí, meu!");
		} else if (senha!=confsenha){ 
			alert("Repete as duas senhas, né, meu!");
		} else {
			$.ajax({
				type: "POST",
				url: "InsereUsuario",
				data: $("#cadastroUsuario").serialize(),
				success: function (msg) {
					alert(msg.msg);
				},
				error: function (info) {
					alert("Erro ao cadastrar um novo jogador: "+ info.status + " - " + info.statusText);		   
				}
			});
		}
	}
});
