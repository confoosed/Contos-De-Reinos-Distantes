package br.com.contos.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import br.com.contos.classes.Notificacao;
import br.com.contos.jdbcinterfaces.NotificacaoDAO;

public class JDBCNotificacaoDAO implements NotificacaoDAO{
	
	private Connection conexao;

	public JDBCNotificacaoDAO(Connection conexao) {
		this.conexao = conexao;
	}
	
	public boolean inserir(Notificacao notificacao){
		String comando = "INSERT INTO notificacacoes (notificacao, data_criacao, usuario_id) VALUES (?,?,?)";
		PreparedStatement p;
		try{
			p = this.conexao.prepareStatement(comando);
			p.setString(1, notificacao.getNotificacao());
			p.setString(2, notificacao.getDataCriacao());
			p.setString(3, notificacao.getUsuario().getId());
			p.execute();
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;
		}
	
	public boolean atualizar(Notificacao notificacao){
		String comando = "UPDATE notificacoes SET notificacao=?";
		comando += " WHERE notificacao=?";
		PreparedStatement p;
		try {
			p = this.conexao.prepareStatement(comando);
			p.setString(1, notificacao.getNotificacao());
			p.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean deletar(String id) {
		String comando = "DELETE FROM notificacoes WHERE id = '" + id +"'";
		Statement p;
		try {
			p = this.conexao.createStatement();
			p.execute(comando);
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public List<Notificacao> buscar() {
		String comando = "SELECT * FROM notificacoes";
		System.out.println(comando);
		List<Notificacao> listNotificacao = new ArrayList<Notificacao>();
		Notificacao notificacao = null;
		try {
			Statement stmt = conexao.createStatement(); 
			ResultSet rs = stmt.executeQuery(comando);
			while (rs.next()) {
				notificacao = new Notificacao();
				String notif = rs.getString("notificacao");
				String datacriacao = notificacao.converteCriacaoParaFrontend(rs.getString("data_criacao"));
				String usuarioid = rs.getString("usuario_id");				
				notificacao.setNotificacao(notif);
				notificacao.setDataCriacao(datacriacao);
				notificacao.setUsuarioId(usuarioid);
				listNotificacao.add(notificacao);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return listNotificacao;
	}
	
}
